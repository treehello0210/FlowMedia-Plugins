"""Store the bounded result supplied by the FlowMedia SDK 2 host adapter."""
from flowmedia_plugin import FlowMediaPlugin


class Plugin(FlowMediaPlugin):
    def run(self, event=None):
        snapshot = self.get_service_snapshot()
        ok = snapshot.get("ok") is True
        previous = self.get_data("status")
        self.save_data("status", ok)
        self.save_data("checked_at", snapshot.get("checked_at"))
        self.save_data("summary", snapshot.get("summary", {}))
        if previous is not ok or (event or {}).get("type") == "plugin.manual":
            self.notify("success" if ok else "failure", "info" if ok else "warning")
        return {"ok": ok}
